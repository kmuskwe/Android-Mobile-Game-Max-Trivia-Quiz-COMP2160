package com.example.maxtriviaquiz;

// imported relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity
{

    // Created ImageButton, Button, TextView and MediaPlayer variables
    ImageButton backbutton;
    ImageButton submitbutton;
    Button decreasebutton;
    Button increasebutton;

    TextView textvolumelevel;
    MediaPlayer mp;

    float volumelevel = 0.4f;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // set the variables to the actual elements
        backbutton = findViewById(R.id.back3);
        submitbutton = findViewById(R.id.submit2);
        decreasebutton = findViewById(R.id.decrease);
        increasebutton = findViewById(R.id.increase);
        textvolumelevel = findViewById(R.id.volumeamount);

        // created a MediaPlayer that starts playing music
        mp  = MediaPlayer.create(MainActivity4.this, R.raw.music);
        mp.setLooping(true);
        mp.setVolume(volumelevel, volumelevel);
        mp.start();

        // changes screen to home screen when selected
        backbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity4.this, MainActivity.class);
                startActivity(intent);

            }
        });

        // saves changes upon submit button being selected
        submitbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(MainActivity4.this, MainActivity.class);
                startActivity(intent);

            }
        });


        // increases the volume on click
        increasebutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // if volume has not reached max volume increase the volumes
                if (volumelevel < 1)
                {
                    volumelevel = volumelevel + 0.1f;
                    mp.setVolume(volumelevel, volumelevel);
                    String stringvolumelevel = textvolumelevel.getText().toString();
                    int intvolumelevel = Integer.parseInt(stringvolumelevel);

                    // ensures the volume text is no greater than max of 100
                    if (intvolumelevel < 100)
                    {
                        intvolumelevel = intvolumelevel + 10;
                        String newvolumelevel = Integer.toString(intvolumelevel);
                        textvolumelevel.setText(newvolumelevel);
                    }

                }
            }
        });

        // decreases the volume on click
        decreasebutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // if volume has not reached minimum volume decreases the volumes
                if (volumelevel > 0.0)
                {
                    volumelevel = volumelevel - 0.1f;
                    mp.setVolume(volumelevel, volumelevel);
                    String stringvolumelevel = textvolumelevel.getText().toString();
                    int intvolumelevel = Integer.parseInt(stringvolumelevel);
                    // ensures the volume text is no less than minimum of 0
                    if (intvolumelevel > 0)
                    {
                        intvolumelevel = intvolumelevel - 10;
                        String newvolumelevel = Integer.toString(intvolumelevel);
                        textvolumelevel.setText(newvolumelevel);
                    }
                }
            }
        });




    }
}