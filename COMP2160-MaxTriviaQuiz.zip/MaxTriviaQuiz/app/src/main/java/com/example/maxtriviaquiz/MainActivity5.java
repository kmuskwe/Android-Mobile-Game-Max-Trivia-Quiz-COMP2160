package com.example.maxtriviaquiz;

// imported relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity5 extends AppCompatActivity
{
    // Created ImageButton and EditText variables
    ImageButton backbutton;
    ImageButton submitbutton;

    EditText username;
    EditText password;

    EditText securitypin;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        // sets the variables to actual elements
        backbutton = findViewById(R.id.back4);
        submitbutton = findViewById(R.id.submit3);
        username = findViewById(R.id.usernameinput);
        password = findViewById(R.id.passwordinput);
        securitypin = findViewById(R.id.securitypininput);


        // goes back to home screen on selection
        backbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                Intent intent = new Intent(MainActivity5.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // saves created username, password and security pin and transitions screen to login screen
        submitbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String stringusername = username.getText().toString();
                String stringpassword = password.getText().toString();
                String stringsecuritypin = securitypin.getText().toString();
                Intent intent = new Intent(MainActivity5.this, MainActivity6.class);
                intent.putExtra("username", stringusername);
                intent.putExtra("password", stringpassword);
                intent.putExtra("securitypin", stringsecuritypin);
                startActivity(intent);

            }
        });


    }
}