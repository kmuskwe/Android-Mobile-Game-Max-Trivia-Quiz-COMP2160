package com.example.maxtriviaquiz;

// imported relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity
{
    // Created ImageButton and TextView variables
    ImageButton backbutton;
    ImageButton submitbutton;

    TextView username2;
    TextView password2;

    TextView securitypin2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        // sets the variables to actual elements
        backbutton = findViewById(R.id.back5);
        submitbutton = findViewById(R.id.submit4);
        username2 = findViewById(R.id.usernameinput2);
        password2 = findViewById(R.id.passwordinput2);
        securitypin2 = findViewById(R.id.securitypininput2);

        String username1 = getIntent().getStringExtra("username");
        String password1 = getIntent().getStringExtra("password");
        String securitypin1 = getIntent().getStringExtra("securitypin");


        //goes back to home screen on click
        backbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity6.this, MainActivity.class);
                startActivity(intent);
            }
        });


        // checks to see if the registered username, password and pin matches the given login ones
        submitbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String stringusername2 = username2.getText().toString();
                String stringpassword2 = password2.getText().toString();
                String stringsecuritypin2 = securitypin2.getText().toString();

                if (stringusername2.equals(username1) && stringpassword2.equals(password1)
                && stringsecuritypin2.equals(securitypin1))
                {
                    Intent intent = new Intent(MainActivity6.this, MainActivity.class);
                    intent.putExtra("username", stringusername2);
                    startActivity(intent);
                }
                else
                {
                    // if username, password and pin do not match states the account does not exist
                    Toast.makeText(MainActivity6.this,
                            "That account does not exist!!!", Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}