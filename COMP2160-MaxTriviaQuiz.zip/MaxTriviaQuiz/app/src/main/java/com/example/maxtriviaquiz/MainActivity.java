package com.example.maxtriviaquiz;

// imported relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    // Created ImageButton, TextView and String variables
    ImageButton playbutton;
    ImageButton helpbutton;
    ImageButton soundbutton;
    ImageButton createaccountbutton;
    ImageButton loginbutton;

    TextView greeting;

    String username;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set the variables to the actual elements
        playbutton = findViewById(R.id.play);
        helpbutton = findViewById(R.id.help);
        soundbutton = findViewById(R.id.sound);
        createaccountbutton = findViewById(R.id.createaccount);
        loginbutton = findViewById(R.id.login);
        greeting = findViewById(R.id.user);

        // gets the username from the intent created by login activity
        username = getIntent().getStringExtra("username");

            // if user has logged in and is not a guest
            if (username != null && !username.isEmpty())
            {
                // set greeting to welcome user with their username
                greeting.setText("Welcome " + username);
            }
            else
            {
                // set greeting to welcome the guest
                greeting.setText("Welcome Guest");
            }

        // if play button is selected, explicit intent is called and changes screen to pick quiz
        playbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        // if help button is selected, explicit intent is called and changes screen to game rules
        helpbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(intent);
            }
        });

        // if sound button is selected, explicit intent is called and changes screen to sound screen
        soundbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        // if create account button is selected, explicit intent opens up account creation screen
        createaccountbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, MainActivity5.class);
                startActivity(intent);
            }
        });

        // if login button is selected, explicit intent opens up login screen
        loginbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, MainActivity6.class);
                startActivity(intent);
            }
        });

    }
}