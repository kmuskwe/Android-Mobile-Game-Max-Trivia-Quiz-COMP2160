package com.example.maxtriviaquiz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity12 extends AppCompatActivity
{
    ImageButton replaybutton;
    ImageButton quitbutton;

    TextView totalscore;
    TextView status;

    int score = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
        replaybutton = findViewById(R.id.replay3);
        quitbutton = findViewById(R.id.quit3);
        totalscore = findViewById(R.id.quizscore3);
        status = findViewById(R.id.status3);

        int hscore = getIntent().getIntExtra("score", score);

        // if medium score is 10 or less display splendid
        if (hscore < 11)
        {
            status.setText("Splendid");
            status.setTextColor(Color.RED);
        }

        // if medium score is greater than 10 display amazing
        if (hscore > 10)
        {
            status.setText("Amazing");
            status.setTextColor(Color.YELLOW);
        }

        // if medium score is 20 or greater display perfect
        if (hscore > 19)
        {
            status.setText("Perfect");
            status.setTextColor(Color.GREEN);
        }


            totalscore.setText(hscore + "/25");



        replaybutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity12.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity12.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}