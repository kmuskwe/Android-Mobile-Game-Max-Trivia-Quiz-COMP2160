package com.example.maxtriviaquiz;

// import relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity7 extends AppCompatActivity
{
    // created ImageButton and TextView variablesa
    ImageButton replaybutton;
    ImageButton quitbutton;

    TextView totalscore;

    TextView status;

    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        // set variables to elements
        replaybutton = findViewById(R.id.replay);
        quitbutton = findViewById(R.id.quit);
        totalscore = findViewById(R.id.quizscore);
        status = findViewById(R.id.status);
        int escore = getIntent().getIntExtra("score", score);

        // if easy score is 10 or less display splendid
        if (escore < 11)
        {
            status.setText("Splendid");
            status.setTextColor(Color.RED);
        }

        // if easy score is greater than 10 display amazing
        if (escore > 10)
        {
            status.setText("Amazing");
            status.setTextColor(Color.YELLOW);
        }

        // if easy score is 20 or greater display perfect
        if (escore > 19)
        {
            status.setText("Perfect");
            status.setTextColor(Color.GREEN);
        }

        totalscore.setText(escore + "/25");



        replaybutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity7.this, MainActivity8.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity7.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}