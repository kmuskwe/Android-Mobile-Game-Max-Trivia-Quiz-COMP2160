package com.example.maxtriviaquiz;

import androidx.appcompat.app.AppCompatActivity;

// created packages
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity8 extends AppCompatActivity
{

    // created TextView and Button variables
    TextView question;
    Button option1, option2, option3, option4, option5;

    Button submit;

    int QuestionIndexPosition = 0;

    int AnswerIndexPosition = 0;

    public int score = 0;
    int attempts = 0;
    int Option1IndexPosition = 0;
    int Option2IndexPosition = 1;
    int Option3IndexPosition = 2;
    int Option4IndexPosition = 3;
    int Option5IndexPosition = 4;

    int hintIndexPosition = 0;

    public String correctanswer;

    public String easyquiztype = "noeasyquiz";

    Button hintbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        // calls the helper function which resets all the variables back to default values
        resetgame();

        // sets variables to specific elements
        question = findViewById(R.id.questiontitle);
        option1 = findViewById(R.id.answer1);
        option2 = findViewById(R.id.answer2);
        option3 = findViewById(R.id.answer3);
        option4 = findViewById(R.id.answer4);
        option5 = findViewById(R.id.answer5);
        submit = findViewById(R.id.submit5);
        hintbutton = findViewById(R.id.hint);

        // sets each question and choices to appropriate value from the given arrays
        question.setText(QuestionandAnswers.easyquestions[QuestionIndexPosition]);
        option1.setText(QuestionandAnswers.easychoices[Option1IndexPosition]);
        option2.setText(QuestionandAnswers.easychoices[Option2IndexPosition]);
        option3.setText(QuestionandAnswers.easychoices[Option3IndexPosition]);
        option4.setText(QuestionandAnswers.easychoices[Option4IndexPosition]);
        option5.setText(QuestionandAnswers.easychoices[Option5IndexPosition]);

        // if selected it displays a hint to answering the question
        hintbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity8.this,
                        QuestionandAnswers.easyhints[hintIndexPosition], Toast.LENGTH_SHORT).show();
            }
        });


        // once button is selected it becomes green and sets all other buttons to purple
        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correctanswer = option1.getText().toString();
                option1.setBackgroundColor(Color.GREEN);
                option2.setBackgroundColor(Color.parseColor("#6200ED"));
                option3.setBackgroundColor(Color.parseColor("#6200ED"));
                option4.setBackgroundColor(Color.parseColor("#6200ED"));
                option5.setBackgroundColor(Color.parseColor("#6200ED"));

            }
        });

        // once button is selected it becomes green and sets all other buttons to purple
        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correctanswer = option2.getText().toString();
                option2.setBackgroundColor(Color.GREEN);
                option1.setBackgroundColor(Color.parseColor("#6200ED"));
                option3.setBackgroundColor(Color.parseColor("#6200ED"));
                option4.setBackgroundColor(Color.parseColor("#6200ED"));
                option5.setBackgroundColor(Color.parseColor("#6200ED"));

            }
        });

        // once button is selected it becomes green and sets all other buttons to purple
        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correctanswer = option3.getText().toString();
                option3.setBackgroundColor(Color.GREEN);
                option1.setBackgroundColor(Color.parseColor("#6200ED"));
                option2.setBackgroundColor(Color.parseColor("#6200ED"));
                option4.setBackgroundColor(Color.parseColor("#6200ED"));
                option5.setBackgroundColor(Color.parseColor("#6200ED"));

            }
        });

        // once button is selected it becomes green and sets all other buttons to purple
        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correctanswer = option4.getText().toString();
                option4.setBackgroundColor(Color.GREEN);
                option1.setBackgroundColor(Color.parseColor("#6200ED"));
                option2.setBackgroundColor(Color.parseColor("#6200ED"));
                option3.setBackgroundColor(Color.parseColor("#6200ED"));
                option5.setBackgroundColor(Color.parseColor("#6200ED"));

            }
        });

        // once button is selected it becomes green and sets all other buttons to purple
        option5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                correctanswer = option5.getText().toString();
                option5.setBackgroundColor(Color.GREEN);
                option1.setBackgroundColor(Color.parseColor("#6200ED"));
                option2.setBackgroundColor(Color.parseColor("#6200ED"));
                option3.setBackgroundColor(Color.parseColor("#6200ED"));
                option4.setBackgroundColor(Color.parseColor("#6200ED"));


            }
        });
        // once all questions are answered it transitions to game over screen and catches errors
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    attempts = attempts + 1;
                    if (attempts == 25) {
                        Intent intent = new Intent(MainActivity8.this,
                                MainActivity7.class);
                        easyquiztype = "easyquiz";
                        intent.putExtra("score", score);
                        intent.putExtra("easyquiztype", easyquiztype);
                        startActivity(intent);
                    }

                    // if correct answer is chosen it increments score and states answer is correct
                    if (correctanswer.equals(QuestionandAnswers.easyanswers[AnswerIndexPosition])) {
                        submit.setBackgroundColor(Color.GREEN);
                        score = score + 1;
                        Toast.makeText(MainActivity8.this,
                                "You selected the correct answer.",
                                Toast.LENGTH_SHORT).show();
                    }

                    // if incorrect answer is chosen it states answer is incorrect
                    if (!correctanswer.equals(QuestionandAnswers.easyanswers[AnswerIndexPosition])) {
                        submit.setBackgroundColor(Color.RED);
                        Toast.makeText(MainActivity8.this,
                                "You selected the incorrect answer.",
                                Toast.LENGTH_SHORT).show();
                    }

                    // increments question, answer and option array position each time submitted
                    QuestionIndexPosition = QuestionIndexPosition + 1;
                    AnswerIndexPosition = AnswerIndexPosition + 1;
                    Option1IndexPosition = Option1IndexPosition + 5;
                    Option2IndexPosition = Option2IndexPosition + 5;
                    Option3IndexPosition = Option3IndexPosition + 5;
                    Option4IndexPosition = Option4IndexPosition + 5;
                    Option5IndexPosition = Option5IndexPosition + 5;
                    hintIndexPosition = hintIndexPosition + 1;
                    question.setText(QuestionandAnswers.easyquestions[QuestionIndexPosition]);
                    option1.setText(QuestionandAnswers.easychoices[Option1IndexPosition]);
                    option2.setText(QuestionandAnswers.easychoices[Option2IndexPosition]);
                    option3.setText(QuestionandAnswers.easychoices[Option3IndexPosition]);
                    option4.setText(QuestionandAnswers.easychoices[Option4IndexPosition]);
                    option5.setText(QuestionandAnswers.easychoices[Option5IndexPosition]);
                    option1.setBackgroundColor(Color.parseColor("#6200ED"));
                    option2.setBackgroundColor(Color.parseColor("#6200ED"));
                    option3.setBackgroundColor(Color.parseColor("#6200ED"));
                    option4.setBackgroundColor(Color.parseColor("#6200ED"));
                    option5.setBackgroundColor(Color.parseColor("#6200ED"));
                } catch (ArrayIndexOutOfBoundsException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    protected void resetgame()
    {
        // sets all index positions back to default values
        QuestionIndexPosition = 0;
        AnswerIndexPosition = 0;
        score = 0;
        attempts = 0;
        hintIndexPosition = 0;
        Option1IndexPosition = 0;
        Option2IndexPosition = 1;
        Option3IndexPosition = 2;
        Option4IndexPosition = 3;
        Option5IndexPosition = 4;
    }
}

