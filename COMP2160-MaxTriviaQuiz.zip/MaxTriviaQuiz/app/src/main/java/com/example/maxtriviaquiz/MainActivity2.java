package com.example.maxtriviaquiz;

// imported relevant packages
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity
{

    // Created ImageButton and String variables
    public ImageButton easybutton;
    public ImageButton mediumbutton;
    public ImageButton hardbutton;
    public ImageButton backbutton;
    public ImageButton submitbutton;
    public String quiztype;

        @Override
        protected void onCreate (Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);

            // set the variables to the actual elements
            easybutton = findViewById(R.id.easy);
            mediumbutton = findViewById(R.id.medium);
            hardbutton = findViewById(R.id.hard);
            backbutton = findViewById(R.id.back);
            submitbutton = findViewById(R.id.submit);

            // if easy button is selected, toast states easy quiz has been chosen
            easybutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    quiztype = "Easy";
                    Toast.makeText(MainActivity2.this,
                            "You have chosen the Easy Quiz", Toast.LENGTH_SHORT).show();
                }
            });

            // if medium button is selected, toast states medium quiz has been chosen
            mediumbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    quiztype = "Medium";
                    Toast.makeText(MainActivity2.this,
                            "You have chosen the Medium Quiz", Toast.LENGTH_SHORT).show();;
                }
            });

            // if hard button is selected, toast states hard quiz has been chosen
            hardbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    quiztype = "Hard";
                    Toast.makeText(MainActivity2.this,
                            "You have chosen the Hard Quiz", Toast.LENGTH_SHORT).show();
                }
            });

            // if back button is selected, explicit intent returns user to home screen
            backbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                    startActivity(intent);
                }
            });

            // if submit button is selected, explicit intent sends user to the chosen quiz
            submitbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // opens up the easy quiz
                    if (quiztype.equals("Easy"))
                    {
                        Intent intent1 = new Intent(MainActivity2.this,
                                MainActivity8.class);
                        startActivity(intent1);
                    }

                    // opens up the medium quiz
                    if (quiztype.equals("Medium"))
                    {
                        Intent intent2 = new Intent(MainActivity2.this,
                                MainActivity9.class);
                        startActivity(intent2);
                    }

                    // opens up the hard quiz
                    if (quiztype.equals("Hard"))
                    {
                        Intent intent3 = new Intent(MainActivity2.this,
                                MainActivity10.class);
                        startActivity(intent3);
                    }
                }
            });


        }
    }

